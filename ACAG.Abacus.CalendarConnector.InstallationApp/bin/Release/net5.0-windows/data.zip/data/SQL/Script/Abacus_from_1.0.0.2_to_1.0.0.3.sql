
DECLARE @OLD_VERSION VARCHAR(10) = '1.0.0.2'
DECLARE @NEW_VERSION VARCHAR(10) = '1.0.0.3'
DECLARE @DATABASEVERSION VARCHAR(50) = 'DATABASEVERSION'

IF OBJECT_ID(N'dbo.AppSetting', N'U') IS NULL
BEGIN
	PRINT 'Create new table AppSetting'
	CREATE TABLE [dbo].[AppSetting](
	[Id] [nvarchar](50) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[Status] [bit] NOT NULL,
 CONSTRAINT [PK_AppSetting] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	INSERT INTO AppSetting([Id], Value, Status)
	VALUES ('DATABASEVERSION',@OLD_VERSION, 1)
END
IF (EXISTS(SELECT * FROM AppSetting WHERE [Id] = @DATABASEVERSION AND [Value] = @OLD_VERSION))
BEGIN
	PRINT ''
	PRINT '===================================================================='
	PRINT 'The using database is: ' + DB_NAME()
	PRINT 'Updating From '+@OLD_VERSION +' to '+@NEW_VERSION +' Data Migration'
	PRINT '===================================================================='
		
	SET NUMERIC_ROUNDABORT OFF

	SET ANSI_PADDING ON

	SET ANSI_WARNINGS ON

	SET CONCAT_NULL_YIELDS_NULL ON

	SET ARITHABORT ON

	SET QUOTED_IDENTIFIER ON

	SET ANSI_NULLS ON

	IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
	CREATE TABLE #tmpErrors(
		Error int
	);
	BEGIN TRY
			
		BEGIN TRAN
		
		DECLARE @ErrorMessage VARCHAR(MAX)
		DECLARE @ErrorSeverity VARCHAR(MAX)

		/*
		* UPDATE CODE WRITE HERE
		*/

		-- DEFAULT ADMIN

		IF NOT EXISTS (SELECT * FROM [User] WHERE [Email] = 'develop@all-consulting.ch')
		BEGIN
			DECLARE @enCultureId INT
			SELECT @enCultureId = Id FROM Culture WHERE Code = 'de'
	
			INSERT INTO [User] (CultureId, FirstName, LastName, Email, Password, SaltPassword, IsEnabled, CreatedBy, CreatedDate)
			VALUES (@enCultureId, 
					N'admin', 
					N'system',
					N'develop@all-consulting.ch', 
					N'7CD4A46E7B0F31EFBFBD1F2B5E7969EFBFBD4EEFBFBDEFBFBDEFBFBD6A6E15EFBFBDEFBFBD3DEFBFBD30D69E44EFBFBD4425', --123456
					N'84b32f39-a6d5-4d5a-908c-538fea22b3d9', 
					1, -1, GETDATE())
		END

		-- SET ADMIN FOR ACCOUNT

		IF NOT EXISTS (SELECT 1 FROM AppRoleRel WHERE UserId = (SELECT Id FROM [User] WHERE [Email] = 'develop@all-consulting.ch') AND AppRoleId = (SELECT Id FROM AppRole WHERE Code = 'Administrator'))
		BEGIN
			DECLARE @adminRoleId INT
			DECLARE @adminId INT

			SELECT @adminRoleId = Id FROM [AppRole] WHERE Code = 'Administrator'
			SELECT @adminId  = Id FROM [User] WHERE [Email] = 'develop@all-consulting.ch'

			INSERT INTO AppRoleRel (AppRoleId, UserId, CreatedBy, CreatedDate) VALUES (@adminRoleId, @adminId , -1, GETDATE())
		END
		


		IF EXISTS (SELECT * FROM [User] WHERE [Email] = 'admin@admin.com')
		BEGIN
			DELETE FROM AppRoleRel
				WHERE UserId = 
				(SELECT Id FROM [User] WHERE [Email] = 'admin@admin.com')
			DELETE FROM [User]
			WHERE Email = 'admin@admin.com'
		END

		-- INIT ROLES

		IF NOT EXISTS (SELECT 1 FROM AppRole WHERE Code = 'SysAdmin')
			INSERT INTO AppRole (Code, IsAdministrator, IsEnabled, CreatedBy, CreatedDate) VALUES ('SysAdmin', 1, 1, -1, GETDATE())
		/*
		* UPDATE CODE END HERE
		*/
		
		--Increase database version
		UPDATE dbo.AppSetting SET [Value] =@NEW_VERSION WHERE [Id] =@DATABASEVERSION
		COMMIT
		PRINT '===================================================================='
		PRINT 'The database update succeeded.'
		PRINT '===================================================================='
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
        ROLLBACK TRAN --RollBack in case of Error
		-- Raise ERROR including the details of the exception
		SET @ErrorMessage = ERROR_MESSAGE();
		SET @errorSeverity = ERROR_SEVERITY();
		RAISERROR(@ErrorMessage, @ErrorSeverity, 1)
	END CATCH
END
ELSE
BEGIN
	PRINT ''
	PRINT 'The database has already been updated to '+@NEW_VERSION
END
